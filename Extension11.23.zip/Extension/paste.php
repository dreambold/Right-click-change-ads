<?php
$code = 'var allFrames = document.querySelectorAll("iframe");'.
'var sep = "\uE000";'.
'window.addEventListener("pagehide", function (e) {'.
    'window.name += sep + window.pageXOffset + sep + window.pageYOf.set;'.
'});'.
'if (window.name && window.name.indexOf(sep) > -1) {'.
    'var parts = window.name.split(sep);'.
    'if (parts.length >= 3) {'.
        'window.name = parts[0];'.
        'window.scrollTo(parseFloat(parts[parts.length - 2]), parse.loat(parts[parts.length - 1]));'.
    '}'.
'}'.
'var position = window.pageYOffset;'.
'var res;'.
'var res0;'.
'var tmpWidth;'.
'var tmpHeight; var currentElement;'.
'var t = document.createElement("input");'.
'document.body.appendChild(t);'.
't.focus();'.
'document.execCommand("paste");'.
'var copiedAd = t.value;'.
'document.body.removeChild(t);'.
'//==================================='.
'if (copiedAd != "" && copiedAd != "null" && copiedAd) {'.
    //=============Yahoo=========================
   //===========================================
'    if (copiedAd.includes(\'width="\')) {'.
'        res = copiedAd.match(/width=\"[0-9]*/);'.
'        res0 = copiedAd.match(/height=\"[0-9]*/);'.
'        tmpWidth = Number(res.toString().replace(\'width=\"\', " "));'.
'        tmpHeight = Number(res0.toString().replace(\'height=\"\', " "));'.
'    }'.
    //==================Google============================
    //=====================================================
'    else if (copiedAd.includes("flexWidth=")) {'.
'        res = copiedAd.match(/flexWidth=[0-9]*/g);'.
'        res0 = copiedAd.match(/flexHeight=[0-9]*/g);'.
'        tmpWidth = Number(res.toString().replace(\'flexWidth=\', " "));'.
'        tmpHeight = Number(res0.toString().replace(\'flexHeight=\', " "));'.
'    }'.
    //==================https://preview-desk.thetradedesk.com===========================
   //============================================================================
'    else if (copiedAd.toString().includes("width: ")) {'.
'        res = copiedAd.match(/width:\s[0-9]*/);'.
'        res0 = copiedAd.match(/height:\s[0-9]*/);'.
'        tmpWidth = Number(res.toString().replace(\'width:\', " "));'.
'        tmpHeight = Number(res0.toString().replace(\'height:\', " "));'.
'    }'.
'    for (var i = 0; i < allFrames.length; i++) {'.
        //Getting the parent element of the iframe
'        var par = allFrames[i].parentNode;'.
'        par.setAttribute("style", "border: none");'.
        //Getting the height and width of the previouse iframe
'        var width = allFrames[i].offsetWidth;'.
'        var height = allFrames[i].offsetHeight;'.
'        if (width / height == tmpWidth / tmpHeight) {'.
'            var elem = document.createElement("div");'.
'            var style = document.createAttribute("style");'.
'            style.value = "width:" + width + "px !important;height:" + height + "px !important;border-style:none !important;";'.
'            elem.setAttributeNode(style);'.
'            //Placing the new iframe inside the DIV'.
'            elem.innerHTML = copiedAd; elem.firstChild.style.border = "none"; elem.firstChild.style.height = allFrames[i].style.height;'.
'            currentElement = elem;'.
'            //Replacing the Old iframe with the new one!'.
'            par.replaceChild(elem, allFrames[i]);'.
'        }'.
'    }'.
'};'.
'window.scrollTo(0, position);';

echo $code;



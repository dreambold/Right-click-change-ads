<?php
$Query_String  = $_REQUEST['link'];
$code = '';
  $code = 'var theVideo = document.querySelectorAll("video")[0];';
$code = $code . 'var body = document.querySelector("body");' .
  //Creating an input field
  'var inputField = document.createElement("input");' .
  'inputField.className = "InputToCopy";' .
  'body.appendChild(inputField);' .
  //Getting the Video inside the Video, we will copy this later.
  ' var str = theVideo.parentElement.children[0].src;' .
  //Selecting the input field
  'var copyText = document.querySelector(".InputToCopy");' .
  //Placing the Video into the input field
  'copyText.value = str;' .
  //Selecting data from the input field
  'copyText.select();' .
  //Copying selected data from the webpage
  'document.execCommand("copy");' .
  //Removing the input field from the webpage
  'body.removeChild(copyText);';
//Excuting the written code on the webpage

echo ($code);

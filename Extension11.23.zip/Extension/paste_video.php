<?php
$code = 'var sep = "\uE000";'.
'window.addEventListener("pagehide", function (e) {'.
    'window.name += sep + window.pageXOffset + sep + window.pageYOf.set;'.
'});'.
'if (window.name && window.name.indexOf(sep) > -1) {'.
    'var parts = window.name.split(sep);'.
    'if (parts.length >= 3) {'.
        'window.name = parts[0];'.
        'window.scrollTo(parseFloat(parts[parts.length - 2]), parse.loat(parts[parts.length - 1]));'.
    '}'.
'}'.
'var position = window.pageYOffset;'.
'var res;'.
'var res0;'.
'var tmpWidth;'.
'var tmpHeight; var currentElement;'.
'var t = document.createElement("input");'.
'document.body.appendChild(t);'.
't.focus();'.
'document.execCommand("paste");'.
'var copiedVideo = t.value;'.
'document.body.removeChild(t);'.
// 'chrome.tabs.query({ "active": true, "lastFocusedWindow": true }, function (tabs) {'.
    'var allFrames;'.
    'allFrames = document.getElementsByClassName("seted_video")[0].parentNode;'.
    // 'if (window.location.href.search("https://edition.cnn.com/videos") == 0) {'.
    //   'allFrames = document.getElementsByClassName("media__video--thumbnail")[0].parentNode;'.
    // '} else if (window.location.href.search("https://www.msn.com/en-us/video") == 0) {'.
    //   'allFrames = document.getElementsByClassName("video_player")[0].parentNode;'.
    // '} else if (window.location.href.search("https://www.yahoo.com/news/") == 0) {'.
    //   'Frames = document.getElementsByClassName("VideoPlayer");'.
    //   'for(var i = 0;Frames.length;i++){'.
    //     'Frames[i].parentNode.innerHTML = "<video preload=\'auto\' style=\'width:100%;\' autoplay controls><source src=\'"+copiedVideo+"\' type=\'video/mp4\'></video>";'.
    //     '}'.
    // '}else if (window.location.href.search("https://www.bloomberg.com/made") == 0) {'.
    //   'allFrames = document.getElementsByClassName("video-player")[0].parentNode;'.
    // '} else if (window.location.href.search("https://www.huffpost.com/section/video") == 0) {'.
    //   'allFrames = document.getElementsByClassName("vdb_player")[0].parentNode;'.
    // '} else if (window.location.href.search("https://www.wsj.com/video") == 0) {'.
    //   'allFrames = document.getElementById("wrapper-player").parentNode;'.
    // '}else if (window.location.href.search("https://www.washingtonpost.com/video/") == 0) {'.
    //   'allFrames = document.getElementById("premium-player");'.
    // '}else if (window.location.href.search("https://www.huffpost.com/entry") == 0) {'.
    //   'allFrames = document.getElementsByClassName("vdb_player")[0].parentNode;'.
    // '}else if (window.location.href.search("https://www.bloomberg.com/news") == 0) {'.
    //   'allFrames = document.getElementsByClassName("video-player")[0].parentNode;'.
    // '}'.
// '    for (var i = 0; i < allFrames.length; i++) {'.
        //Getting the parent element of the iframe
// '        var par = allFrames.parentNode;'.
// 'var pasteVideo = "<video id=\'player1_html5_api\' class=\'vjs-tech\' preload=\'auto\' src=\'https://v.adsrvr.org/video.mp4\' style=\'width:95%;\' autoplay controls>
// <source src=\'https://v.adsrvr.org/video.mp4\' type=\'video/mp4\'></video>";'.
// '        par.setAttribute("style", "border: none");'.
        //Getting the height and width of the previouse iframe
// '        if (width / height == tmpWidth / tmpHeight) {'.
// '            var elem = document.createElement("div");'.
// '            var style = document.createAttribute("style");'.
// '            style.value = "width:" + width + "px !important;height:" + height + "px !important;border-style:none !important;";'.
// '            elem.setAttributeNode(style);'.
// '            //Placing the new iframe inside the DIV'.
'allFrames.innerHTML = "<video preload=\'auto\' style=\'width:100%;\' autoplay controls><source src=\'"+copiedVideo+"\' type=\'video/mp4\'></video>";'.
// '            currentElement = elem;'.<video preload=\'auto\' src=\'https://v.adsrvr.org/video.mp4\' autoplay controls>
// <source src=\'https://v.adsrvr.org/video.mp4\' type=\'video/mp4\'></video>
// '            //Replacing the Old iframe with the new one!'.
// '            par.replaceChild(elem, allFrames);'.
// '        }'.
// '    }'.
// '});'.
'window.scrollTo(0, position);';

echo $code;



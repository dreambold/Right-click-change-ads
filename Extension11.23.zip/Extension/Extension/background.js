//===================Http send request================
//====================================================
var base_url = "http://localhost/Extension/";
var newURL = "https://app.actiondots.com/";

// Creating The Menu Items
// =========================================
chrome.contextMenus.create({
  id: "set",
  title: "Set AD Markers",
  contexts: ["frame"]
});
chrome.contextMenus.create({
  id: "copy",
  title: "Copy an AD tag",
  contexts: ["frame"]
});
chrome.contextMenus.create({
  id: "paste",
  title: "Paste the copied AD tag",
  contexts: ["frame"]
});
chrome.contextMenus.create({
  id: "screenshot",
  title: "Take a screenshot",
  contexts: ["all"]
});
chrome.contextMenus.create({
  id: "clear",
  title: "Clear AD Markers",
  contexts: ["frame"]
});
//=========================================
//===============Video=====================
chrome.contextMenus.create({
  title: "Video",
  id: "parent",
  contexts:["all"]
});

chrome.contextMenus.create({
  id: "set_video",
  title: "Set Video Markers",
  parentId: "parent",
  contexts:["all"],
});

chrome.contextMenus.create({
  id: "copy_video",
  title: "Copy an Video tag",
  parentId: "parent",
  contexts:["all"],
});
chrome.contextMenus.create({
  id: "paste_video",
  title: "Paste the copied AD tag",
  parentId: "parent",
  contexts:["all"],
});

//===================================================
function send_request(session_id, target_url, source_url) {
  // Sending and receiving data in JSON format using POST method
  var xhr = new XMLHttpRequest();
  var url = base_url + "index.php";
  var data = {
    session_id: session_id,
    target_url: target_url,
    source_url: source_url
  };
  xhr.onreadystatechange = function () {
    if (xhr.readyState === 4 && xhr.status === 200) {
      // alert(JSON.parse(this.responseText)['nodata']);
    }
  };
  xhr.open("POST", url, true);
  xhr.send(JSON.stringify(data));
}
//===============================
function doAction(uri, note) {
  var xhr = new XMLHttpRequest();
  var url = base_url + uri;
  xhr.onreadystatechange = function () {
    if (xhr.readyState === 4 && xhr.status === 200) {
      if (this.responseText != '') {
        chrome.tabs.executeScript(null, { "code": this.responseText }, function (result) {
          if (chrome.runtime.lastError) { // or if (!result)
            // Get the error message via chrome.runtime.lastError.message
            notification_show(chrome.runtime.lastError.message);//"Whoops! Something went wrong..."
          }
          else {
            notification_show(note);
          }
        });
      }
      // else {
      // }
    }
  };
  xhr.open("GET", url, true);
  xhr.send();
}


//Taking Action while cliking any of the Menu Items
//=================================================
var target_url;
var source_url;
chrome.contextMenus.onClicked.addListener(function (info, tab) {
  var page_Url = unescape(escape(info.pageUrl));
  if (tab) {
    if (info.menuItemId === "set") {
      target_url = page_Url;// var frameUrl = info.frameUrl ? info.frameUrl : "";
      chrome.cookies.get({ url: "https://app.actiondots.com/", name: 'sessionid' }, function (cookie) {
        if (typeof cookie === 'object' && cookie !== null) {
          doAction('set.php', " Successfully set advertisement markers.");
        }
        else {
          alert("Please login!");
          chrome.tabs.create({ url: newURL });
        }
      });
    }
    if (info.menuItemId === "copy") {
      chrome.tabs.query({ 'active': true, 'lastFocusedWindow': true }, function (tabs) {
        var url = tabs[0].url; source_url = url;
        chrome.cookies.get({ url: "https://app.actiondots.com/", name: 'sessionid' }, function (cookie) {
          if (typeof cookie === 'object' && cookie !== null)
            doAction('copy.php?link=' + url, " Successfully copied advertisement.");
          else {
            alert("Please login!");
            chrome.tabs.create({ url: newURL });
          }
        });
      });

    }
    if (info.menuItemId === "screenshot") {
      //Calling the screenshot function
      chrome.cookies.get({ url: "https://app.actiondots.com/", name: 'sessionid' }, function (cookie) {
        if (typeof cookie === 'object' && cookie !== null) {
          var session_id = cookie.value;
          take_screenshot(page_Url, session_id, target_url, source_url);
        }
        else {
          alert("Please login!");
          chrome.tabs.create({ url: newURL });
        }
      });
    }
    if (info.menuItemId === "clear") {
      if (check_session() == 'true')
        chrome.tabs.executeScript(tab.id, {
          //reloading the web
          code: "location.reload()"
        });
      else {
        alert("Please login!");
        chrome.tabs.create({ url: newURL });
      }
    }
    if (info.menuItemId === "paste") {
      chrome.cookies.get({ url: "https://app.actiondots.com/", name: 'sessionid' }, function (cookie) {
        if (typeof cookie === 'object' && cookie !== null)
          doAction('paste.php', " Successfully pasted advertisement markers.");
        else {
          alert("Please login!");
          chrome.tabs.create({ url: newURL });
        }
      });
    }
    if (info.menuItemId === "set_video") {
      target_url = page_Url;// var frameUrl = info.frameUrl ? info.frameUrl : "";
      chrome.cookies.get({ url: "https://app.actiondots.com/", name: 'sessionid' }, function (cookie) {
        if (typeof cookie === 'object' && cookie !== null) {
          doAction('set_video.php', " Successfully set advertisement markers.");
        }
        else {
          alert("Please login!");
          chrome.tabs.create({ url: newURL });
        }
      });
    }
    if (info.menuItemId === "copy_video") {
      chrome.tabs.query({ 'active': true, 'lastFocusedWindow': true }, function (tabs) {
        var url = tabs[0].url; source_url = url;
        chrome.cookies.get({ url: "https://app.actiondots.com/", name: 'sessionid' }, function (cookie) {
          if (typeof cookie === 'object' && cookie !== null)
            doAction('copy_video.php?link=' + url, " Successfully copied Video.");
          else {
            alert("Please login!");
            chrome.tabs.create({ url: newURL });
          }
        });
      });

    }
    if (info.menuItemId === "paste_video") {
      chrome.cookies.get({ url: "https://app.actiondots.com/", name: 'sessionid' }, function (cookie) {
        if (typeof cookie === 'object' && cookie !== null)
          doAction('paste_video.php', " Successfully pasted video markers.");
        else {
          alert("Please login!");
          chrome.tabs.create({ url: newURL });
        }
      });
    }
  }
});

//==============================================

function take_screenshot(page_Url, session_id, target_url, source_url) {
  var currentdate = new Date();
  var datetime = (currentdate.getMonth() + 1) + "-" +
    currentdate.getDate() + "-" +
    currentdate.getFullYear() + "::" +
    currentdate.getHours() + ":" +
    currentdate.getMinutes() + ":" +
    currentdate.getSeconds();
  var date = currentdate.getFullYear() + "-"
    + (currentdate.getMonth() + 1) + "-"
    + currentdate.getDate();

  function extractHostname() {
    var hostname;
    if (page_Url.indexOf("//") > -1) {
      hostname = page_Url.split('/')[2];
    }
    else {
      hostname = page_Url.split('/')[0];
    }
    //find & remove port number
    hostname = hostname.split(':')[0];
    //find & remove "?"
    hostname = hostname.split('?')[0];

    return hostname;
  }

  var screenshot = {
    content: document.createElement("canvas"),
    data: '',

    init: function () {
      send_request(session_id, target_url, source_url);

      this.initEvents(page_Url, session_id, target_url, source_url);
    },
    saveScreenshot: function (page_Url, session_id, target_url, source_url) {
      var image = new Image();
      image.onload = function () {
        var canvas = screenshot.content;
        canvas.width = image.width;
        canvas.height = image.height;
        var context = canvas.getContext("2d");
        context.drawImage(image, 0, 0);

        // save the image
        var link = document.createElement('a');
        link.download = extractHostname(page_Url) + " " + datetime + ".jpg";
        link.href = screenshot.content.toDataURL();
        link.click();


        screenshot.data = '';
      };
      image.src = screenshot.data;
    },
    initEvents: function (page_Url, session_id, target_url, source_url) {

      chrome.tabs.captureVisibleTab(null, { format: "png" }, function (data) {
        screenshot.data = data;
        screenshot.saveScreenshot(page_Url, session_id, target_url, source_url);

      });
    }
  };
  screenshot.init(page_Url, session_id, target_url, source_url);
}
//================Notification show==========================================

function notification_show(e) {
  var time = /(..)(:..)/.exec(new Date());     // The prettyprinted time.
  var hour = time[1] % 12 || 12;               // The prettyprinted hour.
  var period = time[1] < 12 ? 'a.m.' : 'p.m.'; // The period of the day.
  new Notification(hour + time[2] + ' ' + period, {
    icon: 'imageinfo-48.png',
    body: e
  });
}
// ==================================================================
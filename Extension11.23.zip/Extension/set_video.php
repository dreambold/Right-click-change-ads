<?php
$code = 'var allFrames;'.
'if (window.location.href.search("https://edition.cnn.com/videos") == 0) {'.
  'allFrames = document.getElementsByClassName("media__video--thumbnail")[0].parentNode;'.
'} else if (window.location.href.search("https://www.msn.com/en-us/video") == 0) {'.
  'allFrames = document.getElementsByClassName("video_player")[0].parentNode;'.
'} else if (window.location.href.search("https://www.yahoo.com/news/") == 0) {'.
  'Frames = document.getElementsByClassName("VideoPlayer");'.
  'for(var i = 0;Frames.length;i++){'.
    'Frames[i].parentNode.innerHTML = "<video class = \'seted_video\' style=\'background-color:gray;width:100%;\'><source type=\'video/mp4\'></video>";'.
    '}'.
'}else if (window.location.href.search("https://www.bloomberg.com/made") == 0) {'.
  'allFrames = document.getElementsByClassName("video-player")[0].parentNode;'.
'} else if (window.location.href.search("https://www.huffpost.com/section/video") == 0) {'.
  'allFrames = document.getElementsByClassName("vdb_player")[0].parentNode;'.
'} else if (window.location.href.search("https://www.wsj.com/video") == 0) {'.
  'allFrames = document.getElementById("wrapper-player").parentNode;'.
'}else if (window.location.href.search("https://www.washingtonpost.com/video/") == 0) {'.
  'allFrames = document.getElementsByClassName("powa-pane")[0].parentNode;'.
'}else if (window.location.href.search("https://www.huffpost.com/entry") == 0) {'.
  'allFrames = document.getElementsByClassName("vdb_player")[0].parentNode;'.
'}else if (window.location.href.search("https://www.bloomberg.com/news") == 0) {'.
  'allFrames = document.getElementsByClassName("video-player")[0].parentNode;'.
'}'.
'allFrames.innerHTML = "<video class = \'seted_video\' style=\'background-color:gray;width:100%;\'><source type=\'video/mp4\'></video>";';
// 'var videoheight = allFrames.height;'.
// 'var videowidth = allFrames.width;'.
// // 'alert(JSON.stringify(the_video));'.
// 'var overlayer = document.createElement("div");'.
// 'var style = document.createAttribute("style");'.
// 'style.value = "width:" + videowidth + "px;height:" + videoheight + "px; overflow: hidden;";'.
// 'overlayer.setAttributeNode(style);'.
// 'var frameborder = document.createAttribute("frameborder");'.
// 'frameborder.value = "0";'.
// 'overlayer.setAttributeNode(frameborder);'.
// 'var scrolling = document.createAttribute("scrolling");'.
// 'scrolling.value = "no";'.
// 'overlayer.setAttributeNode(scrolling);'.
// 'var att = document.createAttribute("srcdoc");'.
// 'var textnode = document.createTextNode("");'.
// 'att.value = "<div id=\'tmpDiv_" + i + "\' style=\'height: 95vh; width: 95vw; background: gray; display: flex; flex-wrap: wrap; justify-content: center; align-items: center;color: rgba(255,255,255,.6); font-size: 2em;\'></div>";'.
// 'overlayer.setAttributeNode(att);'.
// 'allFrames.parentNode.replaceChild(overlayer, allFrames);';
echo $code;

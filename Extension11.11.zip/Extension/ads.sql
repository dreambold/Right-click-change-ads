/*
SQLyog Enterprise Trial - MySQL GUI v7.11 
MySQL - 5.5.5-10.4.6-MariaDB : Database - ads
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;

CREATE DATABASE /*!32312 IF NOT EXISTS*/`ads` /*!40100 DEFAULT CHARACTER SET utf8 */;

USE `ads`;

/*Table structure for table `ads` */

DROP TABLE IF EXISTS `ads`;

CREATE TABLE `ads` (
  `id` int(55) NOT NULL AUTO_INCREMENT,
  `user_id` varchar(55) DEFAULT NULL,
  `target_url` varchar(555) DEFAULT NULL,
  `source_url` varchar(555) DEFAULT NULL,
  `date_time` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

/*Data for the table `ads` */

insert  into `ads`(`id`,`user_id`,`target_url`,`source_url`,`date_time`) values (1,'1','kkllstarget.com','sourceurl','2019-10-27 18:31:02'),(2,'1','target_url','source_url','2019-10-27 18:44:43'),(3,'1','https://www.w3schools.com/html/html5_webstorage.asp','https://admanagerplus.yahoo.com/preview/share/PuhJ-Oe3NwJLi8YIKFF0rJgDe4a2NlrXQUkvN6NGPiw','2019-10-27 18:47:42'),(4,'1','https://www.w3schools.com/html/html5_webstorage.asp','https://admanagerplus.yahoo.com/preview/share/t8FPYZ1n6xbcKRbhH2uhpV6OrSR0rD6h5rEuMMxjNhY','2019-10-29 01:26:46'),(5,'3t4rfwq73lnph8kzhl1aiht2wkbvy36f','https://www.w3schools.com/php/','https://admanagerplus.yahoo.com/preview/share/t8FPYZ1n6xbcKRbhH2uhpV6OrSR0rD6h5rEuMMxjNhY','2019-10-29 11:55:28');

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;

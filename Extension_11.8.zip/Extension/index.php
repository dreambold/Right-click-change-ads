<?php

require('connect.php');
header("Content-Type: application/json");
$v = json_decode(stripslashes(file_get_contents("php://input")));

$user_id = $v->session_id;
$target_url = $v->target_url;
$source_url = $v->source_url;

if ($user_id != '' && $target_url != '') {
    $sql = "INSERT INTO ads (user_id, target_url, source_url) VALUES ('$user_id', '$target_url', '$source_url')";
    if ($conn->query($sql) === true) {
        echo "New record created successfully";
    }
} else {
    echo "Please Enter the Data!";
}
$rows['nodata']="false";
echo json_encode($rows);
$conn->close();

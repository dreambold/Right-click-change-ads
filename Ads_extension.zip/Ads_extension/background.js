//Creating The Menu Items
//=========================================
chrome.contextMenus.create({
  id: "context1",
  title: "Set AD Markers",
  contexts: ["frame"]
});

chrome.contextMenus.create({
  id: "context2",
  title: "Copy an AD tag",
  contexts: ["frame"]
});
chrome.contextMenus.create({
  id: "context3",
  title: "Paste the copied AD tag",
  contexts: ["frame"]
});
chrome.contextMenus.create({
  id: "context4",
  title: "Take a screenshot",
  contexts: ["all"]
});
chrome.contextMenus.create({
  id: "context5",
  title: "Clear AD Markers",
  contexts: ["frame"]
});

//Taking Action while cliking any of the Menu Items
//=============================================================

chrome.contextMenus.onClicked.addListener(function (info, tab) {
  var page_Url = unescape(escape(info.pageUrl));
  if (tab) {
    if (info.menuItemId === "context1") {
      var frameUrl = info.frameUrl ? info.frameUrl : "";
        //Writing the code to execute on a webpage!
        //Selecting All the iframes on the webpage
        var codes = 'var allFrames = document.querySelectorAll("iframe");' +
        'for(var i = 0; i < allFrames.length; i++){'+
        'var the_frame = allFrames[i];'+
        //Creating an overlayer for each ads to mark
        'var overlayer = document.createElement("div");'+
        'var att = document.createAttribute("style");'+
        //The Custom Ad Marker text (Add something between the "" to show them while marking an ads)
        'var textnode = document.createTextNode("");'+
        'overlayer.appendChild(textnode);'+
        //Styling the Overlayer as a gray layer and placing this over all elements of an ad!
        'att.value = "height: 100%; width: 100%;position: absolute; top: 0; left: 0; z-index: 999999999999; background: gray; display: flex; flex-wrap: wrap; justify-content: center; align-items: center;color: rgba(255,255,255,.6); font-size: 2em;";'+
        'overlayer.setAttributeNode(att);'+
        //Activing the overlayer on an ad!
        'the_frame.contentWindow.document.getElementsByTagName("body")[0].appendChild(overlayer)'+
        '}';
        //Excuting the written code on the webpage
        chrome.tabs.executeScript(null, {"code": codes });
      var set_ad = " Successfully set advertisement markers."
      notification_show(set_ad);

    }
    if (info.menuItemId === "context2") {
      //Writing the code to execute on a webpage!
      //Selecting the body of the webpage
      var code = 'var body = document.querySelector("body");'+
      //Creating an input field
      'var inputField = document.createElement("input");'+
      'inputField.className = "InputToCopy";'+
      'body.appendChild(inputField);'+
      //Getting the iframe inside the iframe, we will copy this later.
      'var theIframe = document.querySelectorAll("iframe")[1].contentWindow.document.querySelector("iframe");'+
      //Generating and placing the copiable iframe in the str variable
      'var str = "<iframe";'+
      //Re-aranging the arrtibutes to copy
      'for (var att, i = 0, atts = theIframe.attributes, n = atts.length; i < n; i++){'+
        'att = atts[i];'+
        'str += " "+att.nodeName+"=\'"+att.nodeValue+"\'";'+
      '}'+
      'str += ">";'+
      //Selecting the input field
      'var copyText = document.querySelector(".InputToCopy");'+
      //Placing the iframe into the input field
      'copyText.value = str;'+
      //Selecting data from the input field
      'copyText.select();'+
      //Copying selected data from the webpage
      'document.execCommand("copy");'+
      //Removing the input field from the webpage
      'body.removeChild(copyText);';
      //Excuting the written code on the webpage
      chrome.tabs.executeScript(null, {"code": code });
    }
    if (info.menuItemId === "context4") {
      //Calling the screenshot function
      take_screenshot();
    }
    if (info.menuItemId === "context5") {
      chrome.tabs.executeScript(tab.id, {
        //reloading the web
        code: "location.reload()"
      });
    }
    if (info.menuItemId === "context3") {
      //Writing code to execute on the webpage
      //Selecting all iframes on the webpage
      var codes = 'var allFrames = document.querySelectorAll("iframe");' +
                  //Asking for the copied ad iframe
                  'var copiedAd = prompt("Please Past Your Copied Ad Frame Here");'+
                  //Selecting all iframes on the webpage to replace with new iframe
                  'for(var i = 0; i < allFrames.length; i++){'+
                    //Getting the parent element of the iframe
                    'var par = allFrames[i].parentNode;'+
                    //Getting the height and width of the previouse iframe
                    'var width = allFrames[i].width;'+
                    'var height = allFrames[i].height;'+
                    //Creating a DIV to place the new iframe
                    'var elem = document.createElement("div");'+
                    //Making the new DIV size as the previouse iframe size
                    'var style = document.createAttribute("style");'+
                    'style.value = "width:"+width+"px !important;height:"+height+"px !important";'+
                    'elem.setAttributeNode(style);'+
                    //Placing the new iframe inside the DIV
                    'elem.innerHTML = copiedAd;'+
                    //Replacing the Old iframe with the new one!
                    'par.replaceChild(elem, allFrames[i]);'+
                  '}';
      chrome.tabs.executeScript(null, {"code": codes });
    }
  }
});


//==============================================
function take_screenshot() {
  var id = 100;
  chrome.tabs.captureVisibleTab(function (screenshotUrl) {

    var viewTabUrl = chrome.extension.getURL('screenshot.html?id=' + id++)
    var targetId = null;

    chrome.tabs.onUpdated.addListener(function listener(tabId, changedProps) {

      if (tabId != targetId || changedProps.status != "complete")
        return;

      chrome.tabs.onUpdated.removeListener(listener);
      var views = chrome.extension.getViews();
      for (var i = 0; i < views.length; i++) {
        var view = views[i];
        if (view.location.href == viewTabUrl) {
          view.setScreenshotUrl(screenshotUrl);
          break;
        }
      }
    });

    chrome.tabs.create({ url: viewTabUrl }, function (tab) {
      targetId = tab.id;
    });



  });
  // OneDrive.save(viewTabUrl);
  var screen = "Screenshot have been saved to computer.";
  notification_show(screen);
}


//================Notification show==========================================

function notification_show(e) {
  var time = /(..)(:..)/.exec(new Date());     // The prettyprinted time.
  var hour = time[1] % 12 || 12;               // The prettyprinted hour.
  var period = time[1] < 12 ? 'a.m.' : 'p.m.'; // The period of the day.
  new Notification(hour + time[2] + ' ' + period, {
    icon: 'imageinfo-48.png',
    body: e
  });
}

//================================================================
//==================================================================



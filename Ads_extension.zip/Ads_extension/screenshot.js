function setScreenshotUrl(url) {
    document.getElementById('target').src = url;
    var donwload = document.getElementById("saveToLocal");
    donwload.href = url;
    donwload.click();
    window.close();
}
document.addEventListener('DOMContentLoaded', function () {
    document.getElementById('print').addEventListener('click', function () {
        window.print();                                             // Print preview
        window.PPClose = true;
    });
});


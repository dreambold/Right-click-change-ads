<?php
$code = 'var allFrames = document.querySelectorAll("iframe");'.
'for (var i = 0; i < allFrames.length; i++) {'.
'var the_frame = allFrames[i];'.
'var framehight = the_frame.height;'.
'var framewidth = the_frame.width;'.
'var overlayer = document.createElement("iframe");'.
'var style = document.createAttribute("style");'.
'style.value = "width:" + framewidth + "px;height:" + framehight + "px; overflow: hidden;";'.
'overlayer.setAttributeNode(style);'.
'var frameborder = document.createAttribute("frameborder");'.
'frameborder.value = "0";'.
'overlayer.setAttributeNode(frameborder);'.
'var scrolling = document.createAttribute("scrolling");'.
'scrolling.value = "no";'.
'overlayer.setAttributeNode(scrolling);'.
'var att = document.createAttribute("srcdoc");'.
'var textnode = document.createTextNode("");'.
'att.value = "<div id=\'tmpDiv_" + i + "\' style=\'height: 95vh; width: 95vw; background: gray; display: flex; flex-wrap: wrap; justify-content: center; align-items: center;color: rgba(255,255,255,.6); font-size: 2em;\'></div>";'.
'overlayer.setAttributeNode(att);'.
'the_frame.parentNode.replaceChild(overlayer, the_frame);'.
'};';
echo $code;
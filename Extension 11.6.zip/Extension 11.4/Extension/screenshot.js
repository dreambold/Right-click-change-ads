function parseURLParams(url) {
    var queryStart = url.indexOf("?") + 1,
        queryEnd = url.indexOf("#") + 1 || url.length + 1,
        query = url.slice(queryStart, queryEnd - 1),
        pairs = query.replace(/\+/g, " ").split("&"),
        parms = {}, i, n, v, nv;

    if (query === url || query === "") return;

    for (i = 0; i < pairs.length; i++) {
        nv = pairs[i].split("=", 2);
        n = decodeURIComponent(nv[0]);
        v = decodeURIComponent(nv[1]);

        if (!parms.hasOwnProperty(n)) parms[n] = [];
        parms[n].push(nv.length === 2 ? v : null);
    }
    return parms;
}
function extractHostname(url) {
    var hostname;
    //find & remove protocol (http, ftp, etc.) and get hostname

    if (url.indexOf("//") > -1) {
        hostname = url.split('/')[2];
    }
    else {
        hostname = url.split('/')[0];
    }

    //find & remove port number
    hostname = hostname.split(':')[0];
    //find & remove "?"
    hostname = hostname.split('?')[0];

    return hostname;
}
var currentdate = new Date();
var datetime = currentdate.getFullYear() + "-"
    + (currentdate.getMonth() + 1) + "-"
    + currentdate.getDate() + " at "
    + currentdate.getHours() + ":"
    + currentdate.getMinutes() + ":"
    + currentdate.getSeconds();
function setScreenshotUrl(url) {
    document.getElementById('target').src = url;
    var donwload = document.getElementById("saveToLocal");
    donwload.href = url;
    var cURL = parseURLParams(window.location.href).source[0];
    donwload.download = extractHostname(cURL) + " " + datetime + ".jpg";
    donwload.click();
    window.close();
}
document.addEventListener('DOMContentLoaded', function () {
    document.getElementById('print').addEventListener('click', function () {
        window.print();                                             // Print preview
        window.PPClose = true;
    });
});


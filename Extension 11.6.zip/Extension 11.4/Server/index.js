//===================Http send request================
//====================================================
var base_url = "http://localhost/Extension/"
function send_request(session_id, target_url, source_url) {
  // Sending and receiving data in JSON format using POST method

  var xhr = new XMLHttpRequest();
  var url = base_url + "index.php";
  var data = {
    session_id: session_id,
    target_url: target_url,
    source_url: source_url
  };
  xhr.onreadystatechange = function () {
    if (xhr.readyState === 4 && xhr.status === 200) {
      // alert(JSON.parse(this.responseText)['nodata']);
    }
  };
  xhr.open("POST", url, true);
  xhr.send(JSON.stringify(data)); 
  alert(session_id +": "+ target_url +": " + source_url);
}

// Creating The Menu Items
// =========================================
chrome.contextMenus.create({
  id: "set",
  title: "Set AD Markers",
  contexts: ["frame"]
});

chrome.contextMenus.create({
  id: "copy",
  title: "Copy an AD tag",
  contexts: ["frame"]
});
chrome.contextMenus.create({
  id: "paste",
  title: "Paste the copied AD tag",
  contexts: ["frame"]
});
chrome.contextMenus.create({
  id: "screenshot",
  title: "Take a screenshot",
  contexts: ["all"]
});
chrome.contextMenus.create({
  id: "clear",
  title: "Clear AD Markers",
  contexts: ["frame"]
});
//Taking Action while cliking any of the Menu Items
//=================================================
var chrome_tabs = chrome_tabs;
chrome.contextMenus.onClicked.addListener(function (info, tab) {
  var target_url;
  var source_url;
  var page_Url = unescape(escape(info.pageUrl));
  if (tab) {
    if (info.menuItemId === "set") {
      target_url = page_Url;
      var frameUrl = info.frameUrl ? info.frameUrl : "";
      chrome.cookies.get({ url: "https://app.actiondots.com/", name: 'sessionid' }, function (cookie) {
        // alert(JSON.stringify(cookie));
        if (typeof cookie === 'object' && cookie !== null) {
          var codes = 'var allFrames = document.querySelectorAll("iframe");' +
            'for(var i = 0; i < allFrames.length; i++){' +
            'var the_frame = allFrames[i];' +
            'var framehight = the_frame.height;' +
            'var framewidth = the_frame.width;' +
            //Creating an overlayer for each ads to mark
            'var overlayer = document.createElement("iframe");' +
            'var style = document.createAttribute("style");' +
            'style.value = "width:"+framewidth+"px;height:"+framehight+"px; overflow: hidden;";' +
            'overlayer.setAttributeNode(style);' +
            'var frameborder = document.createAttribute("frameborder");' +
            'frameborder.value = "0";' +
            'overlayer.setAttributeNode(frameborder);' +
            'var scrolling = document.createAttribute("scrolling");' +
            'scrolling.value = "no";' +
            'overlayer.setAttributeNode(scrolling);' +
            'var att = document.createAttribute("srcdoc");' +
            //The Custom Ad Marker text (Add something between the "" to show them while marking an ads)
            'var textnode = document.createTextNode("");' +
            //'overlayer.appendChild(textnode);'+
            //Styling the Overlayer as a gray layer and placing this over all elements of an ad!
            'att.value = "<div id=\'tmpDiv_" + i + "\' style=\'height: 95vh; width: 95vw; background: gray; display: flex; flex-wrap: wrap; justify-content: center; align-items: center;color: rgba(255,255,255,.6); font-size: 2em;\'></div>";' +
            'overlayer.setAttributeNode(att);' +
            //Activing the overlayer on an ad!
            //'the_frame.contentWindow.document.getElementsByTagName("body")[0].appendChild(overlayer)'+
            'the_frame.parentNode.replaceChild(overlayer,the_frame);' +
            '};';
          //Excuting the written code on the webpage
          chrome_tabs.executeScript(null, { "code": codes });
          var set_ad = " Successfully set advertisement markers.";
          notification_show(set_ad);
        }
        else
          alert("Please login!");
      });
    }
    if (info.menuItemId === "copy") {

      chrome_tabs.query({ 'active': true, 'lastFocusedWindow': true }, function (tabs) {
        var url = tabs[0].url; var code = '';
        source_url = url;
        if (url.search("https://displayvideo.google.com/doubleclick/preview") == 0) {
          code = 'var theIframe = document.querySelectorAll("iframe")[1];';
        } else if (url.search("https://preview-desk.thetradedesk.com/Creatives/") == 0) {
          code = 'var theIframe = document.querySelectorAll("iframe")[0].nextSibling;';
        } else if (url.search("https://admanagerplus.yahoo.com/preview/share/") == 0) {
          code = 'var theIframe = document.querySelectorAll("iframe")[1];';//.contentWindow.document.querySelector("iframe");
        }
        code += 'var body = document.querySelector("body");' +
          //Creating an input field
          'var inputField = document.createElement("input");' +
          'inputField.className = "InputToCopy";' +
          'body.appendChild(inputField);' +
          //Getting the iframe inside the iframe, we will copy this later.
          ' var str = theIframe.outerHTML;' +
          //Selecting the input field
          'var copyText = document.querySelector(".InputToCopy");' +
          //Placing the iframe into the input field
          'copyText.value = str;' +
          //Selecting data from the input field
          'copyText.select();' +
          //Copying selected data from the webpage
          'document.execCommand("copy");' +
          //Removing the input field from the webpage
          'body.removeChild(copyText);';
        //Excuting the written code on the webpage
        chrome_tabs.executeScript(null, { "code": code });
      });
      var set_ad = " Successfully copied advertisement.";
      notification_show(set_ad);
    }
    if (info.menuItemId === "screenshot") {
      //Calling the screenshot function
      chrome.cookies.get({ url: "https://app.actiondots.com/", name: 'sessionid' }, function (cookie) {
        if (typeof cookie === 'object' && cookie !== null) {
          var session_id = cookie.value;
          alert(unescape(escape(info.pageUrl))+ "," + tabs[0].url);
          take_screenshot(page_Url, session_id, target_url, source_url); //unescape(escape(info.pageUrl)), tabs[0].url
        }
        else
          alert("Please login!");
      });
    }
    if (info.menuItemId === "clear") {
      chrome_tabs.executeScript(tab.id, {
        //reloading the web
        code: "location.reload()"
      });
    }
    if (info.menuItemId === "paste") {
      chrome.cookies.get({ url: "https://app.actiondots.com/", name: 'sessionid' }, function (cookie) {

        if (typeof cookie === 'object' && cookie !== null) {
          paste();
        }
        else
          alert("Please login!");
      });
    }
  }
});

//==============================================
function paste() {
  var codes = 'var allFrames = document.querySelectorAll("iframe");' +
    'var sep = "\uE000"; ' +
    ' window.addEventListener("pagehide", function (e) {' +
    ' window.name += sep + window.pageXOffset + sep + window.pageYOffset;' +
    '});' +

    'if (window.name && window.name.indexOf(sep) > -1) {' +
    'var parts = window.name.split(sep);' +
    'if (parts.length >= 3) {' +
    ' window.name = parts[0];' +
    'window.scrollTo(parseFloat(parts[parts.length - 2]), parseFloat(parts[parts.length - 1]));' +
    '}' +
    '}' +
    'var position = window.pageYOffset;' +
    'var res;' +
    'var res0;' +
    'var tmpWidth;' +
    'var tmpHeight; var currentElement;' +
    // 'var copiedAd = prompt("Please Past Your Copied Ad Frame Here");'+
    //Selecting all iframes on the webpage to replace with new iframe
    'var t = document.createElement("input");' +
    'document.body.appendChild(t);' +
    't.focus();' +
    'document.execCommand("paste");' +
    'var copiedAd = t.value;' + //this is your clipboard data
    'document.body.removeChild(t);' +
    //===================================
    'if(copiedAd != "" && copiedAd != "null" && copiedAd){' +
    //=============Yahoo=========================
    //===========================================
    'if(copiedAd.includes(\'width="\')){' +
    ' res = copiedAd.match(/width=\"[0-9]*/);' +
    ' res0 = copiedAd.match(/height=\"[0-9]*/);' +
    ' tmpWidth = Number(res.toString().replace(\'width=\"\', " "));' +
    ' tmpHeight = Number(res0.toString().replace(\'height=\"\', " "));' +
    '}' +
    //==================Google============================
    //=====================================================
    'else if(copiedAd.includes("flexWidth=")){' +
    ' res = copiedAd.match(/flexWidth=[0-9]*/g);' +
    ' res0 = copiedAd.match(/flexHeight=[0-9]*/g);' +
    ' tmpWidth = Number(res.toString().replace(\'flexWidth=\', " "));' +
    ' tmpHeight = Number(res0.toString().replace(\'flexHeight=\', " "));' +
    '}' +
    //==================https://preview-desk.thetradedesk.com===========================
    //============================================================================
    'else if(copiedAd.toString().includes(/width:\s[0-9]*/g)){' +
    ' res = copiedAd.match(/width:\s[0-9]*/g);' +
    ' res0 = copiedAd.match(/height:\s[0-9]*/g);' + 'alert(res);' +
    'alert(res0);' +
    ' tmpWidth = Number(res.toString().replace(\'width:\s\', " "));' +
    ' tmpHeight = Number(res0.toString().replace(\'height:\s\', " "));' +
    '}' +

    'for(var i = 0; i < allFrames.length; i++){' +
    //Getting the parent element of the iframe
    'var par = allFrames[i].parentNode;' +
    'par.setAttribute("style", "border: none");' +
    //Getting the height and width of the previouse iframe
    'var width = allFrames[i].offsetWidth;' +
    'var height = allFrames[i].offsetHeight;' +
    'if(width == tmpWidth && height == tmpHeight){' +
    'var elem = document.createElement("div");' +
    'var style = document.createAttribute("style");' +
    'style.value = "width:"+width +"px !important;height:"+height +"px !important;border-style:none !important;";' +
    'elem.setAttributeNode(style);' +
    //Placing the new iframe inside the DIV
    'elem.innerHTML = copiedAd; elem.firstChild.style.border="none"; elem.firstChild.style.height=allFrames[i].style.height;' +
    'currentElement = elem;' +
    //Replacing the Old iframe with the new one!
    'par.replaceChild(elem, allFrames[i]);' +
    '}' +
    '}' +
    '};' +
    // 'var curEle = document.querySelectorAll("iframe")[currentElement];' +
    'window.scrollTo(0, position);';
  chrome_tabs.executeScript(null, { "code": codes });
}

function take_screenshot(page_Url, session_id, target_url, source_url) {
  
  var currentdate = new Date();
  var datetime = (currentdate.getMonth() + 1) + "-" +
    currentdate.getDate() + "-" +
    currentdate.getFullYear() + "::" +
    currentdate.getHours() + ":" +
    currentdate.getMinutes() + ":" +
    currentdate.getSeconds();
  var date = currentdate.getFullYear() + "-"
    + (currentdate.getMonth() + 1) + "-"
    + currentdate.getDate();

  function extractHostname() {
    var hostname;
    if (page_Url.indexOf("//") > -1) {
      hostname = page_Url.split('/')[2];
    }
    else {
      hostname = page_Url.split('/')[0];
    }
    //find & remove port number
    hostname = hostname.split(':')[0];
    //find & remove "?"
    hostname = hostname.split('?')[0];

    return hostname;
  }

  var screenshot = {
    content: document.createElement("canvas"),
    data: '',

    init: function (page_Url, session_id, target_url, source_url) {
      send_request(session_id, target_url, source_url);

      this.initEvents(page_Url, session_id, target_url, source_url);
    },
    saveScreenshot: function (page_Url, session_id, target_url, source_url) {
      var image = new Image();
      image.onload = function () {
        var canvas = screenshot.content;
        canvas.width = image.width;
        canvas.height = image.height;
        var context = canvas.getContext("2d");
        context.drawImage(image, 0, 0);

        // save the image
        var link = document.createElement('a');
        link.download = extractHostname(page_Url) + " " + datetime + ".jpg";
        link.href = screenshot.content.toDataURL();
        link.click();


        screenshot.data = '';
      };
      image.src = screenshot.data;
    },
    initEvents: function (page_Url, session_id, target_url, source_url) {

      chrome_tabs.captureVisibleTab(null, { format: "png" }, function (data) {
        screenshot.data = data;
        screenshot.saveScreenshot(page_Url, session_id, target_url, source_url);

      });
    }
  };
  screenshot.init(page_Url, session_id, target_url, source_url);
}
//================Notification show==========================================

function notification_show(e) {
  var time = /(..)(:..)/.exec(new Date());     // The prettyprinted time.
  var hour = time[1] % 12 || 12;               // The prettyprinted hour.
  var period = time[1] < 12 ? 'a.m.' : 'p.m.'; // The period of the day.
  new Notification(hour + time[2] + ' ' + period, {
    icon: 'imageinfo-48.png',
    body: e
  });
}
// ================================================================
// ==================================================================
<?php

$Query_String  = $_REQUEST['link'];

$code = '';
if (stripos($Query_String, "https://displayvideo.google.com/doubleclick/preview") !== false) {
  $code = 'var theIframe = document.querySelectorAll("iframe")[1];';
} else if (stripos($Query_String, "https://preview-desk.thetradedesk.com/Creatives/") !== false) {
  $code = 'var theIframe = document.querySelectorAll("ins")[0];';
} else if (stripos($Query_String, "https://admanagerplus.yahoo.com/preview/share/") !== false) {
  $code = 'var theIframe = document.querySelectorAll("iframe")[1];';
} else if (stripos($Query_String, "https://portal.adelphic.com/") !== false) {
  $code = 'var theIframe = document.querySelectorAll("ins")[0];';
} else if (stripos($Query_String, "https://ad.ipredictive.com/d/render/") !== false) {
  $code = 'var theIframe = document.querySelectorAll("ins")[0];';
} 
$code = $code . 'var body = document.querySelector("body");' .
  //Creating an input field
  'var inputField = document.createElement("input");' .
  'inputField.className = "InputToCopy";' .
  'body.appendChild(inputField);' .
  //Getting the iframe inside the iframe, we will copy this later.
  ' var str = theIframe.outerHTML;' .
  //Selecting the input field
  'var copyText = document.querySelector(".InputToCopy");' .
  //Placing the iframe into the input field
  'copyText.value = str;' .
  //Selecting data from the input field
  'copyText.select();' .
  //Copying selected data from the webpage
  'document.execCommand("copy");' .
  //Removing the input field from the webpage
  'body.removeChild(copyText);;';
//Excuting the written code on the webpage

echo ($code);
